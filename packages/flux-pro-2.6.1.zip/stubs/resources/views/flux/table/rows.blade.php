@blaze

<tbody {{ $attributes }} data-flux-rows>
    {{ $slot }}
</tbody>
